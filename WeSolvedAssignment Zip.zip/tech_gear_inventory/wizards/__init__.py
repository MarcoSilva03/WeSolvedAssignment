# -*- coding: utf-8 -*-

from . import product_template_import_wizard
